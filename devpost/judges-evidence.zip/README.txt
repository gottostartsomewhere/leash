Leash, evidence for judges
==========================

redteam-strategy-search.json
  The deterministic attacker. 316 attempts across five objectives,
  297 refused, 19 allowed and every one of those genuinely inside the
  mandate, zero breaches. "campaigns" lists the five objectives.

redteam-llm.json
  The model attacker, openai/gpt-oss-20b on Groq. 6 attempts, 5 refused,
  zero breaches. This is the run after the fix. The run before it found a
  charge of exactly the per-purchase cap falling between the per-item
  check and the structuring check, which is described in the writeup and
  is covered by a regression test in tests/.

  Both files together are the 322 attempts the video reports.

openapi.json
  The committed API definition. Every endpoint declares its response
  shape as a Pydantic response_model, so this is enforced by the
  handlers rather than described alongside them, and a test fails if
  this file drifts from the running app. Regenerate with
  python scripts/export_openapi.py

Source: https://github.com/gottostartsomewhere/leash
