Leash, evidence for judges
==========================

Everything here was produced by the real system. The two new files were
captured from the deployed site on 2026-11-09, not from a laptop.

redteam-strategy-search.json
  The deterministic attacker. 316 attempts across five objectives,
  297 refused, 19 allowed and every one of those genuinely inside the
  mandate, zero breaches. "campaigns" lists the five objectives. The
  "Try to break it" button on the live page runs this same search
  against a sandbox copy of the mandate.

redteam-llm.json
  The model attacker, openai/gpt-oss-20b on Groq. 6 attempts, 5 refused,
  zero breaches. This is the run after the fix. The run before it found a
  charge of exactly the per-purchase cap falling between the per-item
  check and the structuring check, which is described in the writeup and
  is covered by a regression test in tests/.

  Both files together are the 322 attempts the writeup and the live page
  report.

draft-groceries.json
  A mandate written in plain English and drafted by the live model, the
  full response of POST /mandates/draft for "Groceries only. $150 for the
  week, never more than $40 at any one shop, and no alcohol." It shows
  the terms as the engine read them, what the model assumed, "no alcohol"
  under unclear (a category can't exclude one item, so it is shown as not
  enforced rather than pretended), the worst an agent could do inside the
  terms, and the attack run on the draft before anyone signs it. Nothing
  here changes the live mandate; signing is a separate request.

mcp-session.txt
  An outside agent on a Leash. scripts/agent_probe.py speaks the Model
  Context Protocol through the official client, the way Claude or ChatGPT
  would, against https://leash-api-sm0h.onrender.com/mcp. It reads the
  mandate, is refused a $999 chair and told $100 would clear, buys a
  $90.55 one inside the cap, and has a $75 + $75 split across one
  merchant's two addresses caught as structuring. It made holds only:
  the server has no tool that moves money.

openapi.json
  The committed API definition, 19 endpoints. Every endpoint declares its
  response shape as a Pydantic response_model, so this is enforced by the
  handlers rather than described alongside them, and a test fails if
  this file drifts from the running app. Regenerate with
  python scripts/export_openapi.py

Source: https://github.com/gottostartsomewhere/leash
